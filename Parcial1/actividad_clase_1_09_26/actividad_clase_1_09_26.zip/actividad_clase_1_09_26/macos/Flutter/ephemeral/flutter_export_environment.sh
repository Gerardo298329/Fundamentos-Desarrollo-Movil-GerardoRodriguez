#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\Programas_\Dev\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\geras\Documents\++++Ingenieria Computacion+++\Semestre 9\18_Desarrollo_Movil\Parcial1\actividad_clase_1_09_26"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\geras\Documents\++++Ingenieria Computacion+++\Semestre 9\18_Desarrollo_Movil\Parcial1\actividad_clase_1_09_26\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
