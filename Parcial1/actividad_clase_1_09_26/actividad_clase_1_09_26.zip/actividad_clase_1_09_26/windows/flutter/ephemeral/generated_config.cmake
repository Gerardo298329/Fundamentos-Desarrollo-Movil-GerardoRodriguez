# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\Programas_\\Dev\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\geras\\Documents\\++++Ingenieria Computacion+++\\Semestre 9\\18_Desarrollo_Movil\\Parcial1\\actividad_clase_1_09_26" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\Programas_\\Dev\\flutter"
  "PROJECT_DIR=C:\\Users\\geras\\Documents\\++++Ingenieria Computacion+++\\Semestre 9\\18_Desarrollo_Movil\\Parcial1\\actividad_clase_1_09_26"
  "FLUTTER_ROOT=D:\\Programas_\\Dev\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\geras\\Documents\\++++Ingenieria Computacion+++\\Semestre 9\\18_Desarrollo_Movil\\Parcial1\\actividad_clase_1_09_26\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\geras\\Documents\\++++Ingenieria Computacion+++\\Semestre 9\\18_Desarrollo_Movil\\Parcial1\\actividad_clase_1_09_26"
  "FLUTTER_TARGET=C:\\Users\\geras\\Documents\\++++Ingenieria Computacion+++\\Semestre 9\\18_Desarrollo_Movil\\Parcial1\\actividad_clase_1_09_26\\lib\\main.dart"
  "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl,RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuMg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZDNiMTRjODc2OQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049YTgwNGIyNjE2NA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\geras\\Documents\\++++Ingenieria Computacion+++\\Semestre 9\\18_Desarrollo_Movil\\Parcial1\\actividad_clase_1_09_26\\.dart_tool\\package_config.json"
)
