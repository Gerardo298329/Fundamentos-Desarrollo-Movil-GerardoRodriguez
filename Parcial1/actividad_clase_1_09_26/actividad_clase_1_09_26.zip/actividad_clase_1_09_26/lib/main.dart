import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Registro de Preferencias',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const RegistroScreen(),
    );
  }
}

class RegistroScreen extends StatefulWidget {
  const RegistroScreen({super.key});

  @override
  State<RegistroScreen> createState() => _RegistroScreenState();
}

class _RegistroScreenState extends State<RegistroScreen> {
  final _nombreController = TextEditingController();
  final _edadController = TextEditingController();

  String _genero = 'Masculino';
  String _pais = 'Mexico';

  final Map<String, bool> _intereses = {
    'Deporte': false,
    'Musica': false,
    'Cine': false,
    'Lectura': false,
  };

  @override
  void dispose() {
    _nombreController.dispose();
    _edadController.dispose();
    super.dispose();
  }

  void _showSnackBar(String mensaje) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        duration: const Duration(seconds: 3),
        action: SnackBarAction(
          label: 'Cerrar',
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          },
        ),
      ),
    );
  }

  void _mostrarPreferencias() {
    final interesesSeleccionados = _intereses.entries
        .where((e) => e.value)
        .map((e) => e.key)
        .join(', ');

    final resumen = 'Nombre: ${_nombreController.text.isEmpty ? "(vacio)" : _nombreController.text} | '
        'Genero: $_genero | '
        'Intereses: ${interesesSeleccionados.isEmpty ? "ninguno" : interesesSeleccionados} | '
        'Pais: $_pais';

    _showSnackBar(resumen);
  }

  void _guardarRegistro() {
    _showSnackBar('Registro guardado correctamente');
  }

  @override
  Widget build(BuildContext context) {
    return Banner(
      message: 'DEMO',
      location: BannerLocation.topEnd,
      color: Colors.red,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: AppBar(
          title: const Text('Registro de Preferencias'),
          backgroundColor: Theme.of(context).colorScheme.primary,
          foregroundColor: Colors.white,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Seccion 1: Informacion General
              _SectionCard(
                color: Colors.blue.shade50,
                borderColor: Colors.blue.shade200,
                icon: Icons.info_outline,
                iconColor: Colors.blue,
                title: 'Seccion 1: Informacion General',
                child: const Text(
                  'Completa los siguientes datos personales basicos',
                  style: TextStyle(color: Colors.black54),
                ),
              ),
              const SizedBox(height: 16),

              // Seccion 2: Datos Personales
              _SectionCard(
                color: Colors.green.shade50,
                borderColor: Colors.green.shade200,
                icon: Icons.person_outline,
                iconColor: Colors.green,
                title: 'Seccion 2: Datos Personales',
                child: Column(
                  children: [
                    TextField(
                      controller: _nombreController,
                      decoration: const InputDecoration(
                        labelText: 'Nombre completo',
                        prefixIcon: Icon(Icons.person),
                        border: OutlineInputBorder(),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _edadController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Edad',
                        prefixIcon: Icon(Icons.calendar_today),
                        border: OutlineInputBorder(),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Seccion 3: Distribucion en Filas
              _SectionCard(
                color: Colors.orange.shade50,
                borderColor: Colors.orange.shade200,
                icon: Icons.table_rows_outlined,
                iconColor: Colors.orange,
                title: 'Seccion 3: Distribucion en Filas',
                child: Column(
                  children: [
                    _FilaColor(color: Colors.red, label: 'Fila 1 - Color Rojo', bg: Colors.red.shade200),
                    const SizedBox(height: 8),
                    _FilaColor(color: Colors.amber, label: 'Fila 2 - Color Amarillo', bg: Colors.amber.shade200),
                    const SizedBox(height: 8),
                    _FilaColor(color: Colors.blue, label: 'Fila 3 - Color Azul', bg: Colors.blue.shade50),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Seccion 4: Cuatro Hijos en Colores
              _SectionCard(
                color: Colors.purple.shade50,
                borderColor: Colors.purple.shade200,
                icon: Icons.grid_view_outlined,
                iconColor: Colors.purple,
                title: 'Seccion 4: Cuatro Hijos en Colores',
                child: Row(
                  children: [
                    Expanded(child: _HijoChip(label: 'Hijo 1', color: Colors.red.shade100, textColor: Colors.red.shade900)),
                    const SizedBox(width: 8),
                    Expanded(child: _HijoChip(label: 'Hijo 2', color: Colors.orange.shade100, textColor: Colors.orange.shade900)),
                    const SizedBox(width: 8),
                    Expanded(child: _HijoChip(label: 'Hijo 3', color: Colors.green.shade100, textColor: Colors.green.shade900)),
                    const SizedBox(width: 8),
                    Expanded(child: _HijoChip(label: 'Hijo 4', color: Colors.purple.shade100, textColor: Colors.purple.shade900)),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Seccion 5: Controles UI
              _SectionCard(
                color: Colors.grey.shade100,
                borderColor: Colors.grey.shade300,
                icon: Icons.add_circle_outline,
                iconColor: Colors.black87,
                title: 'Seccion 5: Controles UI',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Genero:', style: TextStyle(fontWeight: FontWeight.bold)),
                    RadioListTile<String>(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Masculino'),
                      value: 'Masculino',
                      groupValue: _genero,
                      onChanged: (value) => setState(() => _genero = value!),
                    ),
                    RadioListTile<String>(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Femenino'),
                      value: 'Femenino',
                      groupValue: _genero,
                      onChanged: (value) => setState(() => _genero = value!),
                    ),
                    RadioListTile<String>(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Otro'),
                      value: 'Otro',
                      groupValue: _genero,
                      onChanged: (value) => setState(() => _genero = value!),
                    ),
                    const SizedBox(height: 12),
                    const Text('Intereses:', style: TextStyle(fontWeight: FontWeight.bold)),
                    ..._intereses.keys.map((interes) {
                      return CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        title: Text(interes),
                        value: _intereses[interes],
                        onChanged: (value) {
                          setState(() => _intereses[interes] = value ?? false);
                        },
                      );
                    }),
                    const SizedBox(height: 12),
                    const Text('Pais:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      initialValue: _pais,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.public),
                        border: OutlineInputBorder(),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      items: const [
                        DropdownMenuItem(value: 'Mexico', child: Text('Mexico')),
                        DropdownMenuItem(value: 'Estados Unidos', child: Text('Estados Unidos')),
                        DropdownMenuItem(value: 'Espana', child: Text('Espana')),
                        DropdownMenuItem(value: 'Argentina', child: Text('Argentina')),
                      ],
                      onChanged: (value) => setState(() => _pais = value!),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _mostrarPreferencias,
                            icon: const Icon(Icons.visibility),
                            label: const Text('Mostrar Preferencias'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _guardarRegistro,
                            icon: const Icon(Icons.check),
                            label: const Text('Guardar Registro'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

/// Tarjeta reutilizable para cada seccion de la pantalla
class _SectionCard extends StatelessWidget {
  final Color color;
  final Color borderColor;
  final IconData icon;
  final Color iconColor;
  final String title;
  final Widget child;

  const _SectionCard({
    required this.color,
    required this.borderColor,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: iconColor),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

/// Fila coloreada usada en la Seccion 3
class _FilaColor extends StatelessWidget {
  final Color color;
  final Color bg;
  final String label;

  const _FilaColor({required this.color, required this.bg, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          CircleAvatar(radius: 8, backgroundColor: color),
          const SizedBox(width: 10),
          Text(label),
        ],
      ),
    );
  }
}

/// Chip de color usado en la Seccion 4 (Hijo 1..4)
class _HijoChip extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const _HijoChip({required this.label, required this.color, required this.textColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
      ),
    );
  }
}